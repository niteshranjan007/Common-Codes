package com.javacodegeeks.example.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.NoSuchElementException;

public class ProductFileStream {

	   public void writeToFile(List<PersonModel> list, String file) {
	      ObjectOutputStream outStream = null;
	      try {
	         outStream = new ObjectOutputStream(new FileOutputStream(file));
	         for (PersonModel p : list) {
	            outStream.writeObject(p);
	         }

	      } catch (IOException ioException) {
	         System.err.println("Error opening file.");
	      } catch (NoSuchElementException noSuchElementException) {
	         System.err.println("Invalid input.");
	      } finally {
	         try {
	            if (outStream != null)
	               outStream.close();
	         } catch (IOException ioException) {
	            System.err.println("Error closing file.");
	         }
	      }
	   }

	}