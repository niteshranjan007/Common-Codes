package com.test.nitesh;

import java.util.List;

public interface ConsIntakeFormRepository extends JpaRepository<ConsIntakeForm, String> {
	
	List<ConsIntakeForm> findByCrteUsrId(String crteUsrId);

}
