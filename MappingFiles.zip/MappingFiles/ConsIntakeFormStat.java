package com.test.nitesh;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CONS_INTAKE_FORM")
public class ConsIntakeFormStat implements Serializable  {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CONS_INTAKE_FORM_ID")
	private String consIntakeFormId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="INTAKE_HLTH_STAT_CD",referencedColumnName="STAT_CD")
	private Stat Stat;

}
