package com.test.nitesh;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="PROJ_TYP")
public class ProjTyp implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PROJ_TYP_CD")
	private String projTypCd;
	
	@Column(name = "PROJ_TYP_DESC")
	private String projTypDesc;


}
