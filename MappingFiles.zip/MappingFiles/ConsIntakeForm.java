package com.test.nitesh;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CONS_INTAKE_FORM")
public class ConsIntakeForm implements Serializable  {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CONS_INTAKE_FORM_ID")
	private String consIntakeFormId;
	
	@Column(name = "PROJ_NM")
	private String projNm;
	
	@Column(name = "BL_ID")
	private String blId;
	
	@Column(name = "CRTE_USR_ID")
	private String crteUsrId;
	
	@Column(name = "CRTE_TSTP")
	private String crteTstp;
	
	@Column(name = "REQ_RLSE_DT")
	private long reqRlseDt;
	
	@OneToOne(cascade = CascadeType.ALL)	
	@PrimaryKeyJoinColumn
	private IntakeImpactedTool intakeImpactedTool;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="PROJ_TYP_CD",referencedColumnName="PROJ_TYP_CD")
	private ProjTyp projTyp;
	
	@OneToOne(cascade = CascadeType.ALL)	
	@PrimaryKeyJoinColumn
	private ConsIntakeFormStat consIntakeFormStat;

	
}
