package com.springboot.login.utility;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	  @ExceptionHandler(StudentException.class)
	  public final ResponseEntity<ResponseInfo> handleException(StudentException ex) {
		  ResponseInfo responseInfo = new ResponseInfo();
		  responseInfo.setResponseCode("500");
		  responseInfo.setDescription("Internal Server Error");
	    return new ResponseEntity<>(responseInfo, HttpStatus.NOT_FOUND); 

}
}
