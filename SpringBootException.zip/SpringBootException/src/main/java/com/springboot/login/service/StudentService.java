package com.springboot.login.service;

import org.springframework.stereotype.Service;

import com.springboot.login.model.Student;
import com.springboot.login.utility.StudentException;

@Service
public class StudentService {
	
	
	public Student getValue() throws StudentException{
		
		Student ovo = new Student();
        
        try
        { 
        	int[] data = null;
    		
    		int len = data[2];
          
        } 
        catch(NullPointerException ex) 
        { 
           throw new StudentException("");
        }
		return ovo;		
	}

}
