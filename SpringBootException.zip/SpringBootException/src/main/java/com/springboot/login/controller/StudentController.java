package com.springboot.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springboot.login.model.Student;
import com.springboot.login.service.StudentService;
import com.springboot.login.utility.StudentException;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;

	@RequestMapping(value="value", method = RequestMethod.POST)
	public Student getValue(@RequestBody Student ivo){
		
		Student ovo = new Student();
		ovo.setFirstName("Hello Nitesh");
		return ovo;		
	}
	
	@RequestMapping(value="hello", method = RequestMethod.GET)
	public Student getHello() throws StudentException{
		
		studentService.getValue();
		Student ovo = new Student();
		ovo.setFirstName("Hello Nitesh");
		return ovo;		
	}

}
