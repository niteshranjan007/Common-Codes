package com.nitesh.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nitesh.entity.ConsIntakeForm;


@Repository("studentDao")
public class JpaDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	public List<ConsIntakeForm> getUsers() {
		return (List<ConsIntakeForm>) sessionFactory.getCurrentSession().createCriteria(ConsIntakeForm.class).list();
	}
}
