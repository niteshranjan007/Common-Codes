package com.nitesh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nitesh.entity.ConsIntakeForm;
import com.nitesh.service.JpaService;


@Controller
public class JpaController {
	
	@Autowired
	private JpaService jpaService;
	
/*	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}*/
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView test() {
		
		System.out.println("into test");
		
		List<ConsIntakeForm> list = jpaService.getUsers();
		System.out.println(list.toString());
		return new ModelAndView("index");
	}

}
