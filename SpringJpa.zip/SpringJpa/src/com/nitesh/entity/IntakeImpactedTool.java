package com.nitesh.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="INTAKE_IMPACTED_TOOL")
public class IntakeImpactedTool implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CONS_INTAKE_FORM_ID")
	private String consIntakeFormId;
	
	@Column(name = "INTAKE_IMPACTED_TOOL_TYP_CD")
	private String intakeImpactedToolTypCd;

	public String getConsIntakeFormId() {
		return consIntakeFormId;
	}

	public void setConsIntakeFormId(String consIntakeFormId) {
		this.consIntakeFormId = consIntakeFormId;
	}

	public String getIntakeImpactedToolTypCd() {
		return intakeImpactedToolTypCd;
	}

	public void setIntakeImpactedToolTypCd(String intakeImpactedToolTypCd) {
		this.intakeImpactedToolTypCd = intakeImpactedToolTypCd;
	}

	@Override
	public String toString() {
		return "IntakeImpactedTool [consIntakeFormId=" + consIntakeFormId
				+ ", intakeImpactedToolTypCd=" + intakeImpactedToolTypCd + "]";
	}
	
	

}
