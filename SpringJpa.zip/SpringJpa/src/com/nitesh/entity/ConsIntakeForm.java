package com.nitesh.entity;


import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CONS_INTAKE_FORM")
public class ConsIntakeForm implements Serializable  {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CONS_INTAKE_FORM_ID")
	private String consIntakeFormId;
	
	@Column(name = "PROJ_NM")
	private String projNm;
	
	@Column(name = "BL_ID")
	private String blId;
	
	@Column(name = "CRTE_USR_ID")
	private String crteUsrId;
	
	@Column(name = "CRTE_TSTP")
	private String crteTstp;
	
	@Column(name = "REQ_RLSE_DT")
	private String reqRlseDt;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)	
	@PrimaryKeyJoinColumn
	private List<IntakeImpactedTool> intakeImpactedTool;

	public String getConsIntakeFormId() {
		return consIntakeFormId;
	}

	public void setConsIntakeFormId(String consIntakeFormId) {
		this.consIntakeFormId = consIntakeFormId;
	}

	public String getProjNm() {
		return projNm;
	}

	public void setProjNm(String projNm) {
		this.projNm = projNm;
	}

	public String getBlId() {
		return blId;
	}

	public void setBlId(String blId) {
		this.blId = blId;
	}

	public String getCrteUsrId() {
		return crteUsrId;
	}

	public void setCrteUsrId(String crteUsrId) {
		this.crteUsrId = crteUsrId;
	}

	public String getCrteTstp() {
		return crteTstp;
	}

	public void setCrteTstp(String crteTstp) {
		this.crteTstp = crteTstp;
	}

	public String getReqRlseDt() {
		return reqRlseDt;
	}

	public void setReqRlseDt(String reqRlseDt) {
		this.reqRlseDt = reqRlseDt;
	}



	public List<IntakeImpactedTool> getIntakeImpactedTool() {
		return intakeImpactedTool;
	}

	public void setIntakeImpactedTool(List<IntakeImpactedTool> intakeImpactedTool) {
		this.intakeImpactedTool = intakeImpactedTool;
	}

	@Override
	public String toString() {
		return "ConsIntakeForm [consIntakeFormId=" + consIntakeFormId
				+ ", projNm=" + projNm + ", blId=" + blId + ", crteUsrId="
				+ crteUsrId + ", crteTstp=" + crteTstp + ", reqRlseDt="
				+ reqRlseDt + ", intakeImpactedTool=" + intakeImpactedTool
				+ "]";
	}
	

	
}
