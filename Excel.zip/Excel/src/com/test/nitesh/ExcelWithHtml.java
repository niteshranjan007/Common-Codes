package com.test.nitesh;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWithHtml {

	 // <html><p>This is a test. Will this text be <b>bold</b> or
    // <i>italic</i></p></html>

    public static final void main(String[] args) throws FileNotFoundException,
            IOException {
       
   
        InputStream is = ExcelWithHtml.class.getResourceAsStream("D:/excel jars/test.xlsx");
        Workbook wb = new XSSFWorkbook(is);
        Sheet sheet = wb.getSheetAt(0);
        Cell cell = sheet.getRow(0).getCell(0);
        XSSFRichTextString richText = (XSSFRichTextString)cell.getRichStringCellValue();
        int formattingRuns = cell.getRichStringCellValue().numFormattingRuns();

        for(int i = 0; i < formattingRuns; i++)
        {
            int startIdx = richText.getIndexOfFormattingRun(i);
            int length = richText.getLengthOfFormattingRun(i);
            System.out.println("Text: " + richText.getString().substring(startIdx, startIdx + length));
            if(i == 0)
            {
                short fontIndex = cell.getCellStyle().getFontIndex();
                Font f = wb.getFontAt(fontIndex);
                System.out.println("Bold: " + (f.getBoldweight() == Font.BOLDWEIGHT_BOLD));
                System.out.println("Italics: " + f.getItalic() + "\n");
            }
            else
            {
                Font f = richText.getFontOfFormattingRun(i);
                System.out.println("Bold: " + (f.getBoldweight() == Font.BOLDWEIGHT_BOLD));
                System.out.println("Italics: " + f.getItalic() + "\n");
            }
        }
    }
}

   