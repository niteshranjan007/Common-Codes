package com;

public class LoginDAO {
    public static String loginCheck(LoginBean loginBean){
        try{            
            if(loginBean.getEmail().equals("riteshranjan90@gmail.com") && loginBean.getPassword().equals("ritesh")){
                return "true";
            }
            else{
                return "false";
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return "error";
    }
}