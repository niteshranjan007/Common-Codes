package com.raistudies.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.raistudies.domain.JsonResponse;
import com.raistudies.domain.User;
import com.raistudies.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	UserService userService;
	
	private List<User> userList1 = new ArrayList<User>(); 
	
	@RequestMapping(value="/AddUser.htm",method=RequestMethod.GET)
	public String showForm(){
		return "AddUser";
	}
	
	@RequestMapping(value="/AddUser.htm",method=RequestMethod.POST)
	public @ResponseBody JsonResponse addUser(@ModelAttribute(value="user") User user, BindingResult result ){
		JsonResponse res = new JsonResponse();
		System.out.println(user.getName());
		
		List<User> userList = new ArrayList<User>();
		userList=userService.getUsers();
		
		for (int i = 0; i < userList.size(); i++) {
			User user1= new User();
			user1=userList.get(i);
			if(userList.get(i).getName().equals(user.getName())){
			if(userList.get(i).getIndicator().equalsIgnoreCase("Y") && userList.get(i).getExtraIndicator().equalsIgnoreCase("N")){
				System.out.println("into first");

				res.setStatus("SUCCESS");	
				res.setResult(userList.get(i).getName());
			}
			else if(userList.get(i).getIndicator().equalsIgnoreCase("N") && userList.get(i).getExtraIndicator().equalsIgnoreCase("N")){
				System.out.println("into second");
				res.setStatus("SECOND");	
				res.setResult(userList.get(i).getName());
			}
			
			else{
				System.out.println("into third");
				List<String> list= new ArrayList<String>();
				
				list.add("Nitesh");
				list.add("Ranjan");
				res.setList(list);
				res.setStatus("NORMAL");	
			}
			
			
			}
		}		
		
		return res;
	}

	@RequestMapping(value="/ShowUsers.htm")
	public String showUsers(ModelMap model){
		model.addAttribute("Users", userList1);
		return "ShowUsers";
	}
}
