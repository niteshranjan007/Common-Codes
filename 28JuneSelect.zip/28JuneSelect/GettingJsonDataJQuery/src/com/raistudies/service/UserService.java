package com.raistudies.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.raistudies.domain.User;

@Service
public class UserService {
	
	public List<User> getUsers(){
		
		List<User> userList= new ArrayList<User>();
		
		User user1=new User("A","Y","N");
		User user2=new User("B","Y","N");
		User user3=new User("C","Y","N");
		User user4=new User("D","Y","N");
		User user5=new User("E","Y","N");
		User user6=new User("F","Y","N");
		User user7=new User("G","Y","N");
		User user8=new User("H","Y","N");
		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
		userList.add(user4);
		userList.add(user5);
		userList.add(user6);
		userList.add(user7);
		userList.add(user8);

		return userList;
		
		
	}

}
