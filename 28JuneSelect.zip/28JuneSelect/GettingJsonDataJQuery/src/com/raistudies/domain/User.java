package com.raistudies.domain;

public class User {
	
	private String name;
	private String indicator;
	private String extraIndicator;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIndicator() {
		return indicator;
	}
	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	public String getExtraIndicator() {
		return extraIndicator;
	}
	public void setExtraIndicator(String extraIndicator) {
		this.extraIndicator = extraIndicator;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", indicator=" + indicator
				+ ", extraIndicator=" + extraIndicator + "]";
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String name, String indicator, String extraIndicator) {
		super();
		this.name = name;
		this.indicator = indicator;
		this.extraIndicator = extraIndicator;
	}
	
	
}
