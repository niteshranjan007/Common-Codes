package com.springboot.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.login.service.LoginService;

@Controller
public class LoginController {
	
   @Autowired
   LoginService loginService;

   @RequestMapping("/")
   public String index() {
      return "index";
   }

   @RequestMapping(value="/loginValidate", method = RequestMethod.POST)
   public String sayHello(@RequestParam("userName") String userName,@RequestParam("password") String password, Model model) {
     
	   boolean isValidUser = loginService.validateUser(userName, password);
	   if (!isValidUser) {
           model.addAttribute("errorMessage", "Invalid Credentials");
           return "index";
       }
       model.addAttribute("userName", userName);
       return "welcome";
   }
}
