package com.springboot.login.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

	public boolean validateUser(String userName, String password) {
		 return userName.equalsIgnoreCase("nitesh")
	                && password.equalsIgnoreCase("ranjan");
	    }
}
