package net.codejava.spring;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RequestMapping("/uploadFile.do")
public class FileUploadController {
	
	private String saveDirectory = "G:/ATA/nitesh/";
	
	@RequestMapping(value = "/uploadFile.do",method = RequestMethod.POST)
	public ModelAndView handleFileUpload(HttpServletRequest request, 
			@RequestParam CommonsMultipartFile[] fileUpload) throws Exception {
		
		System.out.println("description: " + request.getParameter("description"));
		List<String> fileNames = new ArrayList<String>();
		if (fileUpload != null && fileUpload.length > 0) {
			for (CommonsMultipartFile aFile : fileUpload){
				
				System.out.println("Saving file: " + aFile.getOriginalFilename());
				
				if (!aFile.getOriginalFilename().equals("")) {
					aFile.transferTo(new File(saveDirectory + aFile.getOriginalFilename()));
					String fileName = aFile.getOriginalFilename();
					fileNames.add(fileName);
				}
			}
		}
		// returns to the view "Result"
		return new ModelAndView("Result", "fileNames", fileNames);
	}
	
	@RequestMapping(value = "/download.do", method = RequestMethod.GET)
	public void download(HttpServletResponse response,String name) throws IOException {

		String path = "G:/ATA/nitesh/"+name;
		File file = new File(path);
		InputStream is = new FileInputStream(file);

		// MIME type of the file
		response.setContentType("application/octet-stream");
		// Response header
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ file.getName() + "\"");
		// Read from the file and write into the response
		OutputStream os = response.getOutputStream();
		byte[] buffer = new byte[1024];
		int len;
		while ((len = is.read(buffer)) != -1) {
			os.write(buffer, 0, len);
		}
		os.flush();
		os.close();
		is.close();
	}
}