package java4s;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

@Controller
public class Java4sController {	

	@RequestMapping("/java4s")
	public ModelAndView helloWorld() {

		String sports="";
		String player="";
		ModelAndView mv = new ModelAndView("welcomePage");
		mv.addObject("sports", sports);
		mv.addObject("player", player);
		List<String> sportList=new ArrayList<String>();
		sportList.add("Football");
		sportList.add("Cricket");
		mv.addObject("sportList", sportList);
		return mv;
	}

	@RequestMapping(value = "/java4s1", method = RequestMethod.GET)
	public void helloWorld1(@RequestParam String sportsName,HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hello :"+sportsName);

		List<String> list = new ArrayList<String>();

		if (sportsName.equals("Football")) {
			list.add("Lionel Messi");
			list.add("Cristiano Ronaldo");
			list.add("David Beckham");
			list.add("Diego Maradona");
		} else if (sportsName.equals("Cricket")) {
			list.add("Sourav Ganguly");
			list.add("Sachin Tendulkar");
			list.add("Lance Klusener");
			list.add("Michael Bevan");
		} else if (sportsName.equals("Select Sports")) {
			list.add("Select Player");
		}
		Gson gson = new Gson();
		String json = gson.toJson(list);

		response.setContentType("application/json");
		response.getWriter().write(json);
	}

}
