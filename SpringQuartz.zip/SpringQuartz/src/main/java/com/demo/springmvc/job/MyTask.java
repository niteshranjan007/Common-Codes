package com.demo.springmvc.job;

import java.util.Calendar;

public class MyTask {

	public void doTask() {
		// printing current system time
		System.out.println("Nitesh Ranjan");
		System.out.println("Current Time : "	+ Calendar.getInstance().getTime());
	}
}