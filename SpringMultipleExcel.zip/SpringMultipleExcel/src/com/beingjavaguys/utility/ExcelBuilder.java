package com.beingjavaguys.utility;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.beingjavaguys.domain.Student;
import com.beingjavaguys.domain.Teacher;


public class ExcelBuilder extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// get data model which is passed by the Spring container
		Map<String,Object> map = (Map<String,Object>) model.get("map");
		
		List<Student> studentList = (List<Student>) map.get("student");
		List<Teacher> teacherList = (List<Teacher>) map.get("teacher");
		
		// create a new Student sheet
		HSSFSheet studentSheet = workbook.createSheet("Student");
		studentSheet.setDefaultColumnWidth(30);
		
		// create a new Student sheet
		HSSFSheet teacherSheet = workbook.createSheet("Teacher");
		teacherSheet.setDefaultColumnWidth(30);
		
		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		
		// create header row for Student
		HSSFRow studentHeader = studentSheet.createRow(0);
		
		studentHeader.createCell(0).setCellValue("Name");
		studentHeader.getCell(0).setCellStyle(style);
		
		studentHeader.createCell(1).setCellValue("City");
		studentHeader.getCell(1).setCellStyle(style);
		
		// create header row for Teacher
		HSSFRow teacherHeader = teacherSheet.createRow(0);
		
		teacherHeader.createCell(0).setCellValue("Name");
		teacherHeader.getCell(0).setCellStyle(style);
		
		teacherHeader.createCell(1).setCellValue("Degree");
		teacherHeader.getCell(1).setCellStyle(style);	
		
		
		// create data rows for Student
		int rowCountStudent = 1;
		
		for (Student aStudent : studentList) {
			HSSFRow aRow = studentSheet.createRow(rowCountStudent++);
			aRow.createCell(0).setCellValue(aStudent.getName());
			aRow.createCell(1).setCellValue(aStudent.getCity());
		}
		
		// create data rows for Student
		int rowCountTeacher = 1;
		
		for (Teacher aTeacher : teacherList) {
			HSSFRow aRow = teacherSheet.createRow(rowCountTeacher++);
			aRow.createCell(0).setCellValue(aTeacher.getName());
			aRow.createCell(1).setCellValue(aTeacher.getDegree());
		}
	}



}