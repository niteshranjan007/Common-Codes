package com.beingjavaguys.dao;

import java.util.ArrayList;
import java.util.List;

import com.beingjavaguys.domain.Student;
import com.beingjavaguys.domain.Teacher;

public class UserDaoImpl implements UserDao {


	@Override
	public List<Student> getStudentList() {
		
		
		List<Student> list=new ArrayList<Student>();
		Student stu1= new Student();
		stu1.setName("Nitesh");
		stu1.setCity("Pune");
		
		Student stu2= new Student();
		stu2.setName("Ranjan");
		stu2.setCity("Pune");
		
		list.add(stu1);
		list.add(stu2);
		return list;
	}
	
	@Override
	public List<Teacher> getTeacherList() {
		
		
		List<Teacher> list=new ArrayList<Teacher>();
		Teacher tea1= new Teacher();
		tea1.setName("Rahul");
		tea1.setDegree("MBA");
		
		Teacher tea2= new Teacher();
		tea2.setName("Akash");
		tea2.setDegree("BE");
		
		list.add(tea1);
		list.add(tea2);
		return list;
	}

}
