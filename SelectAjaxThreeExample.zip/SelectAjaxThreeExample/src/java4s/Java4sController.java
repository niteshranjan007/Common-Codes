package java4s;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;

@Controller
public class Java4sController {	

	@RequestMapping("/java4s")
	public ModelAndView helloWorld() {

		String sports="";
		String player="";
		String career="";
		ModelAndView mv = new ModelAndView("welcomePage");
		mv.addObject("sports", sports);
		mv.addObject("player", player);
		mv.addObject("career", career);
		List<String> sportList=new ArrayList<String>();
		sportList.add("Football");
		sportList.add("Cricket");
		mv.addObject("sportList", sportList);
		return mv;
	}

	@RequestMapping(value = "/java4s1", method = RequestMethod.GET)
	public void helloWorld1(@RequestParam String sportsName,HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hello :"+sportsName);

		List<String> list = new ArrayList<String>();

		if (sportsName.equals("Football")) {
			list.add("Select Player");
			list.add("Lionel Messi");
			list.add("Cristiano Ronaldo");
			list.add("David Beckham");
			list.add("Diego Maradona");
		} else if (sportsName.equals("Cricket")) {
			list.add("Select Player");
			list.add("Sourav Ganguly");
			list.add("Sachin Tendulkar");
			list.add("Lance Klusener");
			list.add("Michael Bevan");
		} else {
			list.add("Select Player");
		}
		Gson gson = new Gson();
		String json = gson.toJson(list);

		response.setContentType("application/json");
		response.getWriter().write(json);
	}
	
	@RequestMapping(value = "/java4s2", method = RequestMethod.GET)
	public void helloWorld2(@RequestParam String playerName,HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hello :"+playerName);

		List<String> list = new ArrayList<String>();

		if (playerName.equals("Lionel Messi")) {
			list.add("Select Career");
			list.add("A");
			list.add("B");
			list.add("C");
			list.add("D");
		} else if (playerName.equals("Sachin Tendulkar")) {
			list.add("Select Career");
			list.add("P");
			list.add("Q");
			list.add("R");
			list.add("S");
		} else {
			list.add("Select Career");
		}
		Gson gson = new Gson();
		String json = gson.toJson(list);

		response.setContentType("application/json");
		response.getWriter().write(json);
	}

}
