package com.test.executor;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelSheetData {
	
public static Map<Integer, Integer> setMapData(String path) throws IOException {
	
FileInputStream fis = new FileInputStream(path);
Workbook workbook = new XSSFWorkbook(fis);
Sheet sheet = workbook.getSheetAt(0);
int lastRow = sheet.getLastRowNum();

Map<Integer, Integer> dataMap = new HashMap<Integer, Integer>();

//Looping over entire row
for(int i=1; i<=lastRow; i++){
Row row = sheet.getRow(i);
//1st Cell as Value
Cell valueCell = row.getCell(1);
//0th Cell as Key
Cell keyCell = row.getCell(0);
Integer value = (int) valueCell.getNumericCellValue();
Integer key = (int) keyCell.getNumericCellValue();
//Putting key & value in dataMap
dataMap.put(key, value);
}
//Returning excelFileMap
return dataMap;
}
}