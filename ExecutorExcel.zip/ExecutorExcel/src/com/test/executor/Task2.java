package com.test.executor;

import java.util.Map;
import java.util.concurrent.Callable;

public class Task2 implements Callable<Map<Integer, Integer>> {

	@Override
	public Map<Integer, Integer> call() throws Exception {
		
		final String path = "src/test2.xlsx";
		Map<Integer, Integer> map = ReadExcelSheetData.setMapData(path);
		return map;
	}

}
