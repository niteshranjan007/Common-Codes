package com.test.executor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Client {
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {		
		
		ExecutorService executor = Executors.newFixedThreadPool(2);
		
		TreeMap<Integer, Integer> dataMap = new TreeMap<Integer, Integer>();
		
		Future<Map<Integer, Integer>> future1 = executor.submit(new Task1());
		Future<Map<Integer, Integer>> future2 = executor.submit(new Task2());
		
		dataMap.putAll(future1.get());
		dataMap.putAll(future2.get());
		
		 // Calling the method sortByvalues
	    Map sortedMap = TreeMapCompare.sortByValues(dataMap);
	    
        System.out.println("Content ID with Maximum Duration : "+((TreeMap<Integer, Integer>) sortedMap).lastKey());
        System.out.println("Content ID with Minimum Duration : "+((TreeMap<Integer, Integer>) sortedMap).firstKey());
	 
	    // Get a set of the entries on the sorted map
	    Set set = sortedMap.entrySet();
	 
	    // Get an iterator
	    Iterator i = set.iterator();
	    
	    System.out.println("Content ID" + ": "+ "Duration");
	 
	    // Display elements
	    while(i.hasNext()) {
	      Map.Entry me = (Map.Entry)i.next();
	      System.out.print(me.getKey() + ": ");
	      System.out.println(me.getValue());
	    }
	  }
}
