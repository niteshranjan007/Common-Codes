package com.learnfromexamples.jquerydatatable.service;

import java.util.ArrayList;
import java.util.List;

import com.learnfromexamples.jquerydatatable.modal.Employee;

public class LoadDataService {
	public static List<Employee> getEmployeeList(){
		List<Employee> employeeList = new ArrayList<Employee>();
		Employee employee1 = new Employee("!@#$%^&*()-_+=[]{}|\\:;<>,.?/","Junior Blogger","5000","India");
		
		employeeList.add(employee1);
		return employeeList;
	}

	@Override
	public String toString() {
		return "LoadDataService [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	} 
	
}
