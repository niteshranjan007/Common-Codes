package com.spring.react.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.spring.react.models.Contact;

public interface ContactRepository extends CrudRepository<Contact, String> {
    @Override
    void delete(Contact deleted);

	Optional<Contact> findById(int id);
}
