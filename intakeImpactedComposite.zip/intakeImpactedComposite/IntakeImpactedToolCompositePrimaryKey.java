package com.test.test;

import java.io.Serializable;


public class IntakeImpactedToolCompositePrimaryKey implements Serializable  {
	
	private static final long serialVersionUID = 1L;
	
	private int consIntakeFormId;	
	private String intakeImpactedToolTypCd;
	
	
	public IntakeImpactedToolCompositePrimaryKey(int consIntakeFormId,
			String intakeImpactedToolTypCd) {
		super();
		this.consIntakeFormId = consIntakeFormId;
		this.intakeImpactedToolTypCd = intakeImpactedToolTypCd;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + consIntakeFormId;
		result = prime
				* result
				+ ((intakeImpactedToolTypCd == null) ? 0
						: intakeImpactedToolTypCd.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IntakeImpactedToolCompositePrimaryKey other = (IntakeImpactedToolCompositePrimaryKey) obj;
		if (consIntakeFormId != other.consIntakeFormId)
			return false;
		if (intakeImpactedToolTypCd == null) {
			if (other.intakeImpactedToolTypCd != null)
				return false;
		} else if (!intakeImpactedToolTypCd
				.equals(other.intakeImpactedToolTypCd))
			return false;
		return true;
	}
	
	
	
	
	
	

}
