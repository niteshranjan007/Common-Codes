package com.beingjavaguys.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomePageController {


	@RequestMapping("/register")
	public ModelAndView registerUser() {
		System.out.println("into");
		return new ModelAndView("register");
	}


	/*@RequestMapping("/nitesh")
	public ModelAndView getUserLIst(String message) {
		System.out.println(message);
		String message1=message+" "+"Srivastava";
		return new ModelAndView("register","message1",message1);
	}*/
	
	 @RequestMapping(value="/nitesh",method=RequestMethod.POST)
	    public @ResponseBody String addUser(String message){
		 System.out.println(message);
		 String message1=message+" "+"Srivastava";
	      
	        return message1;
	    }

	
}