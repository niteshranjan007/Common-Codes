package com.beingjavaguys.domain;

public class Teacher {
	
	private String name;
	private String degree;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	

}
