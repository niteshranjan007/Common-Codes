package com.beingjavaguys.dao;

import java.util.ArrayList;
import java.util.List;

import com.beingjavaguys.domain.Student;
import com.beingjavaguys.domain.Teacher;

public class UserDaoImpl implements UserDao {


	@Override
	public List<Student> getStudentList() {
		
		
		List<Student> list=new ArrayList<Student>();
		Student stu1= new Student();
		stu1.setYearCreated("2014");
		stu1.setIdeasSubmitted(396);
		stu1.setSolvedIn2014A(25);
		stu1.setClosededIn2014A(0);
		stu1.setDuplicateIn2014A(0);
		stu1.setSolvedIn2014B(21);
		stu1.setClosededIn2014B(0);
		stu1.setDuplicateIn2014B(0);
		stu1.setSolvedIn2014C(16);
		stu1.setClosededIn2014C(0);
		stu1.setDuplicateIn2014C(0);
		
		
		Student stu2= new Student();
		stu2.setYearCreated("2015");
		stu2.setIdeasSubmitted(396);
		stu2.setSolvedIn2014A(25);
		stu2.setClosededIn2014A(0);
		stu2.setDuplicateIn2014A(0);
		stu2.setSolvedIn2014B(21);
		stu2.setClosededIn2014B(0);
		stu2.setDuplicateIn2014B(0);
		stu2.setSolvedIn2014C(16);
		stu2.setClosededIn2014C(0);
		stu2.setDuplicateIn2014C(0);
		
		Student stu3= new Student();
		stu3.setYearCreated("2016");
		stu3.setIdeasSubmitted(396);
		stu3.setSolvedIn2014A(25);
		stu3.setClosededIn2014A(0);
		stu3.setDuplicateIn2014A(0);
		stu3.setSolvedIn2014B(21);
		stu3.setClosededIn2014B(0);
		stu3.setDuplicateIn2014B(0);
		stu3.setSolvedIn2014C(16);
		stu3.setClosededIn2014C(0);
		stu3.setDuplicateIn2014C(0);
		
		list.add(stu1);
		list.add(stu2);
		list.add(stu3);
		return list;
	}
	
	@Override
	public List<Teacher> getTeacherList() {
		
		
		List<Teacher> list=new ArrayList<Teacher>();
		Teacher tea1= new Teacher();
		tea1.setName("Rahul");
		tea1.setDegree("MBA");
		
		Teacher tea2= new Teacher();
		tea2.setName("Akash");
		tea2.setDegree("BE");
		
		list.add(tea1);
		list.add(tea2);
		return list;
	}

}
