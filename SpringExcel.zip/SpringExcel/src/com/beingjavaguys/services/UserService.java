package com.beingjavaguys.services;

import java.util.List;

import com.beingjavaguys.domain.User;

public interface UserService {

	public List<User> getUserList();

}
